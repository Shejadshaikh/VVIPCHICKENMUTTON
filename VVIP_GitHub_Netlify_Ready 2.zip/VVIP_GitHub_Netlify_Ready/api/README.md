# Production API boundary
Netlify can host the customer/admin static frontend, while production APIs should run through Netlify Functions or a secure backend service with a real database. Paytm secrets must be stored as server environment variables, never in frontend code or GitHub.
