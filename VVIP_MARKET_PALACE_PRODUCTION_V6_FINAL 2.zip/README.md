# VVIP MARKET PALACE — Complete Connected Build V5

Brand: VVIP MARKET PALACE  |  Fresh. Trusted. Delivered.

This package turns the earlier foundation into a functional connected local/production-ready codebase: API, OTP auth flow, products, customer orders, unified order status, admin statistics/settings, seller onboarding, delivery partners, secure QR verification and HALAL flags.

## Run backend
cd backend
npm install
copy `.env.example` to `.env` and set a strong JWT_SECRET
npm start

API: http://localhost:3000

## Important production activation
- Real OTP provider credentials must be configured server-side.
- Paytm secret must be configured server-side; never place it in frontend or GitHub.
- For production, use managed PostgreSQL/Supabase instead of the included SQLite development database, with migrations/backups.
- HTTPS, domain, push notifications, GPS/maps, app-store signing and payment callback/webhook configuration still require the respective provider accounts.
- Do not use the bootstrap admin key in production; create the owner account and rotate credentials immediately.

## Included
customer/  admin/  delivery/  seller/  backend/  config/  docs/
